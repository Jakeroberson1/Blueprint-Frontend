# Chrome Web Store Submission Pack

Use this file while creating the store listing.

## Package to Upload

- Upload this file:
  - `blueprint-canvas-extension-webstore.zip`

## Extension Metadata

- Name: `Blueprint Canvas Connector`
- Short description:
  - `Sync Canvas courses, assignments, grades, planner, calendar, and inbox into Blueprint.`
- Category: `Productivity`
- Language: `English`

## Required URLs

- Homepage URL:
  - `https://blueprint-labs.site`
- Privacy Policy URL:
  - `https://blueprint-labs.site/privacy.html`
- Support URL (recommended):
  - `https://blueprint-labs.site`

## Single Purpose Statement

`Connect a student’s Canvas account in-browser and sync their academic data to their Blueprint account.`

## Permission Justification

- `storage`
  - Stores connector settings, pairing token, and panel UI preferences.
- Host permissions:
  - `https://blueprint-backend-154275778730.us-west1.run.app/*`
  - Sends sync payloads to Blueprint backend over HTTPS.
- Content script matches:
  - `https://*.instructure.com/*`
  - Reads Canvas API data using the student’s existing signed-in Canvas session.

## Data Disclosure (Web Store Form)

- Personal information: Yes (education data and account-linked sync data)
- Authentication information: No passwords collected
- Financial/payment info: No
- Location: No
- Web history: No
- User activity: Limited to manual sync actions
- Website content: Canvas academic content only, on supported Canvas domains
- Data sale: No
- Data transfer purpose: Core extension functionality only

## Manual QA Before Submit

1. Install unpacked extension in a clean Chrome profile.
2. Confirm no panel appears on Canvas login pages.
3. Sign into Canvas and verify panel appears on authenticated pages.
4. Pair with link code and run sync.
5. Confirm synced data appears in Blueprint dashboard.
6. Confirm inbox links open Canvas conversations.
7. Confirm extension icon is visible in Chrome toolbar.
