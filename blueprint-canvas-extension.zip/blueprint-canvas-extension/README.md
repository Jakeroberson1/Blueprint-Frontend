# Blueprint Canvas Sync (Chrome Extension)

This extension lets students sync Canvas data to Blueprint **without** giving Blueprint their Canvas password and without needing a Canvas Developer Key.

How it works:
- The student logs into Canvas normally in their browser (Microsoft SSO + 2FA works as usual).
- The extension runs on Canvas and calls the Canvas API endpoints using the student's existing session.
- The extension uploads the resulting JSON to the Blueprint backend using a **one-time Link Code** generated inside Blueprint.

## Install (developer mode)

1. Open Chrome and go to `chrome://extensions`
2. Enable **Developer mode** (top right)
3. Click **Load unpacked**
4. Select this folder: `blueprint-canvas-extension/`

## Use

1. In Blueprint, go to the Canvas page: `https://blue-printai1.netlify.app/canvas.html`
2. Click **Generate Link Code**
3. Open your Canvas site (example: `https://uvu.instructure.com`) and sign in
4. In the bottom-right of Canvas, the **Blueprint Sync** panel will appear
5. Paste the Link Code and click **Pair** (one time)
6. Click **Sync now**
7. Go back to Blueprint and refresh the Canvas dashboard

## Supported Canvas Domains

By default, the extension runs on:
- `https://*.instructure.com/*`

If your school uses a custom Canvas domain, edit `manifest.json`:
- Add your domain to `host_permissions`
- Add your domain to `content_scripts[0].matches`

Then reload the extension in `chrome://extensions`.

## Backend URL

Default backend API base:
- `https://blueprint-backend-154275778730.us-west1.run.app`

You can override it inside the panel under **Blueprint API Base (advanced)**.
