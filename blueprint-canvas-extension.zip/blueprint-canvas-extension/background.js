'use strict';

const DEFAULT_API_BASE = 'https://blueprint-backend-154275778730.us-west1.run.app';

function normalizeApiBase(apiBase) {
  const base = String(apiBase || '').trim() || DEFAULT_API_BASE;
  return base.replace(/\/+$/, '');
}

async function postJson(url, body, extraHeaders = {}) {
  const res = await fetch(url, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      ...extraHeaders,
    },
    body: JSON.stringify(body || {}),
  });

  const text = await res.text();
  let json = null;
  try {
    json = text ? JSON.parse(text) : null;
  } catch {
    // ignore
  }

  if (!res.ok) {
    const msg = json?.error || json?.message || text || `HTTP ${res.status}`;
    throw new Error(msg);
  }

  return json;
}

function sanitizeLinkCode(code) {
  return String(code || '')
    .toUpperCase()
    .replace(/[^A-Z0-9]/g, '')
    .slice(0, 16);
}

async function getConfig() {
  const stored = await chrome.storage.sync.get([
    'apiBase',
    'deviceToken',
    'pairedUser',
    'pairedAt',
    'lastSyncAt',
    'lastSyncSummary',
    'panelHidden',
    'minimized',
    'posX',
    'posY',
  ]);

  return {
    apiBase: normalizeApiBase(stored.apiBase),
    deviceToken: stored.deviceToken || null,
    pairedUser: stored.pairedUser || null,
    pairedAt: stored.pairedAt || null,
    lastSyncAt: stored.lastSyncAt || null,
    lastSyncSummary: stored.lastSyncSummary || null,
    panelHidden: !!stored.panelHidden,
    minimized: !!stored.minimized,
    posX: Number.isFinite(stored.posX) ? stored.posX : null,
    posY: Number.isFinite(stored.posY) ? stored.posY : null,
  };
}

async function setConfig(patch) {
  await chrome.storage.sync.set(patch);
}

async function clearPairing() {
  await chrome.storage.sync.remove(['deviceToken', 'pairedUser', 'pairedAt', 'lastSyncAt', 'lastSyncSummary']);
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  (async () => {
    const type = msg?.type;

    if (type === 'GET_CONFIG') {
      sendResponse({ ok: true, config: await getConfig() });
      return;
    }

    if (type === 'SET_API_BASE') {
      const apiBase = normalizeApiBase(msg?.apiBase);
      await setConfig({ apiBase });
      sendResponse({ ok: true, apiBase });
      return;
    }

    if (type === 'SET_UI_PREFS') {
      const panelHidden = msg?.panelHidden;
      const minimized = msg?.minimized;
      const posX = msg?.posX;
      const posY = msg?.posY;

      const patch = {};
      if (panelHidden !== undefined) patch.panelHidden = !!panelHidden;
      if (minimized !== undefined) patch.minimized = !!minimized;
      if (posX !== undefined) patch.posX = Number.isFinite(posX) ? posX : null;
      if (posY !== undefined) patch.posY = Number.isFinite(posY) ? posY : null;
      await setConfig(patch);

      sendResponse({ ok: true });
      return;
    }

    if (type === 'CLEAR_PAIRING') {
      await clearPairing();
      sendResponse({ ok: true });
      return;
    }

    if (type === 'EXCHANGE_LINK_CODE') {
      const apiBase = normalizeApiBase(msg?.apiBase);
      const linkCode = sanitizeLinkCode(msg?.linkCode);
      if (!linkCode || linkCode.length < 8) throw new Error('Enter a valid link code.');

      const url = `${apiBase}/api/canvas/link/exchange`;
      const json = await postJson(url, { linkCode });

      const deviceToken = json?.deviceToken;
      if (!deviceToken) throw new Error('Link exchange failed (missing device token).');

      await setConfig({
        apiBase,
        deviceToken,
        pairedUser: json?.user || null,
        pairedAt: new Date().toISOString(),
      });

      sendResponse({ ok: true, deviceToken, user: json?.user || null });
      return;
    }

    if (type === 'IMPORT_DATA') {
      const apiBase = normalizeApiBase(msg?.apiBase);
      const deviceToken = String(msg?.deviceToken || '').trim();
      const payload = msg?.payload;

      if (!deviceToken) throw new Error('Not paired (missing device token).');

      const url = `${apiBase}/api/canvas/import`;
      const json = await postJson(url, payload, { 'X-Blueprint-Canvas-Token': deviceToken });

      const summary = json?.message || 'Canvas data imported.';
      await setConfig({ lastSyncAt: new Date().toISOString(), lastSyncSummary: summary });

      sendResponse({ ok: true, result: json, summary });
      return;
    }

    throw new Error(`Unknown message type: ${type}`);
  })()
    .catch((err) => {
      sendResponse({ ok: false, error: String(err?.message || err) });
    });

  return true;
});
