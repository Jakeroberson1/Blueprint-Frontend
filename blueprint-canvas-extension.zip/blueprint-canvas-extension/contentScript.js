'use strict';

// Only inject once, only in the top frame.
if (window.top === window) {
  const BLUEPRINT_APP_URL = 'https://blue-printai1.netlify.app/canvas.html';

  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

  function el(tag, attrs = {}, children = []) {
    const node = document.createElement(tag);
    for (const [k, v] of Object.entries(attrs || {})) {
      if (v === null || v === undefined || v === false) continue;
      if (k === 'class') node.className = v;
      else if (k === 'text') node.textContent = v;
      else if (k.startsWith('on') && typeof v === 'function') node.addEventListener(k.slice(2), v);
      else if (v === true) node.setAttribute(k, '');
      else node.setAttribute(k, String(v));
    }
    for (const c of children) {
      if (c == null) continue;
      node.appendChild(typeof c === 'string' ? document.createTextNode(c) : c);
    }
    return node;
  }

  function sendMessage(msg) {
    return new Promise((resolve) => {
      chrome.runtime.sendMessage(msg, (resp) => resolve(resp));
    });
  }

  function formatIso(iso) {
    if (!iso) return '';
    try {
      return new Date(iso).toLocaleString();
    } catch {
      return iso;
    }
  }

  function parseLinkHeader(header) {
    // Canvas uses RFC5988-style link headers.
    // Example: <https://.../api/v1/courses?page=2&per_page=100>; rel="next", <...>; rel="last"
    const out = {};
    const h = String(header || '').trim();
    if (!h) return out;

    const parts = h.split(',');
    for (const part of parts) {
      const m = part.match(/<([^>]+)>\s*;\s*rel="([^"]+)"/);
      if (!m) continue;
      out[m[2]] = m[1];
    }
    return out;
  }

  async function fetchJson(url) {
    const res = await fetch(url, {
      method: 'GET',
      credentials: 'include',
      headers: {
        Accept: 'application/json',
      },
    });

    const ct = String(res.headers.get('content-type') || '').toLowerCase();
    if (!res.ok) {
      throw new Error(`Canvas request failed (${res.status}): ${url}`);
    }

    if (!ct.includes('application/json')) {
      const text = await res.text();
      const snippet = String(text || '').replace(/\s+/g, ' ').trim().slice(0, 180);
      throw new Error(`Canvas did not return JSON. Are you logged in? Snippet: ${snippet}`);
    }

    return { data: await res.json(), link: res.headers.get('link') || '' };
  }

  async function fetchAllPages(startUrl, opts = {}) {
    const maxPages = Number(opts.maxPages || 10);
    const maxItems = Number(opts.maxItems || 5000);

    let url = startUrl;
    let page = 0;
    let items = [];

    while (url && page < maxPages && items.length < maxItems) {
      const { data, link } = await fetchJson(url);
      if (Array.isArray(data)) items = items.concat(data);
      else items.push(data);

      const links = parseLinkHeader(link);
      url = links.next || null;
      page += 1;
    }

    return items.slice(0, maxItems);
  }

  async function getCanvasData(progress) {
    const origin = window.location.origin;

    progress(`Fetching courses...`);
    const courses = await fetchAllPages(`${origin}/api/v1/courses?enrollment_state=active&per_page=100`, {
      maxPages: 10,
      maxItems: 1000,
    });

    const courseList = Array.isArray(courses) ? courses : [];

    let assignments = [];
    const courseCount = courseList.length;

    for (let i = 0; i < courseCount; i++) {
      const c = courseList[i];
      const label = c?.name || c?.course_code || `Course ${i + 1}`;
      progress(`Fetching assignments (${i + 1}/${courseCount}): ${label}`);

      try {
        const a = await fetchAllPages(`${origin}/api/v1/courses/${c.id}/assignments?per_page=100`, {
          maxPages: 6,
          maxItems: 2000,
        });

        for (const item of Array.isArray(a) ? a : []) {
          item.course_name = c.name;
          item.course_code = c.course_code;
          assignments.push(item);
        }
      } catch {
        // Skip courses where the API is forbidden or unavailable.
      }

      // Small pause to be nice to the API.
      await sleep(150);
    }

    progress('Fetching grades...');
    const enrollments = await fetchAllPages(`${origin}/api/v1/users/self/enrollments?per_page=100`, {
      maxPages: 10,
      maxItems: 2000,
    });

    const grades = (Array.isArray(enrollments) ? enrollments : []).map((e) => ({
      course_id: e.course_id,
      course_name: courseList.find((c) => c.id === e.course_id)?.name || 'Unknown',
      current_grade: e.grades?.current_grade || 'N/A',
      current_score: e.grades?.current_score ?? null,
    }));



    const start = new Date();
    const end = new Date(Date.now() + 90 * 24 * 60 * 60 * 1000);
    const startIso = start.toISOString();
    const endIso = end.toISOString();

    progress('Fetching planner items (next 90 days)...');
    let plannerItems = [];
    try {
      plannerItems = await fetchAllPages(`${origin}/api/v1/planner/items?per_page=100&start_date=${encodeURIComponent(startIso)}&end_date=${encodeURIComponent(endIso)}`, {
        maxPages: 10,
        maxItems: 2000,
      });
    } catch {
      plannerItems = [];
    }

    progress('Fetching calendar events (next 90 days)...');
    let calendarEvents = [];
    try {
      // Many Canvas instances allow all_events=true for the current user.
      calendarEvents = await fetchAllPages(`${origin}/api/v1/calendar_events?per_page=100&all_events=true&start_date=${encodeURIComponent(startIso)}&end_date=${encodeURIComponent(endIso)}`, {
        maxPages: 10,
        maxItems: 2000,
      });
    } catch {
      calendarEvents = [];
    }

    progress('Fetching announcements...');
    let announcements = [];
    try {
      const contextCodes = courseList
        .map((c) => c && c.id ? `course_${c.id}` : null)
        .filter(Boolean)
        .slice(0, 30);

      if (contextCodes.length) {
        const qs = contextCodes.map((c) => `context_codes[]=${encodeURIComponent(c)}`).join('&');
        announcements = await fetchAllPages(`${origin}/api/v1/announcements?per_page=100&${qs}`, {
          maxPages: 10,
          maxItems: 2000,
        });
      }
    } catch {
      announcements = [];
    }

    return { canvasUrl: origin, courses: courseList, assignments, grades, plannerItems, calendarEvents, announcements, syncedAt: new Date().toISOString() };

  }

  function buildPanel(host, state) {
    const shadow = host.shadowRoot;
    shadow.innerHTML = '';

    function applyPosition(wrapEl) {
      // Default anchor (bottom-right).
      wrapEl.style.right = '18px';
      wrapEl.style.bottom = '18px';
      wrapEl.style.left = '';
      wrapEl.style.top = '';

      if (Number.isFinite(state.posX) && Number.isFinite(state.posY)) {
        wrapEl.style.left = `${state.posX}px`;
        wrapEl.style.top = `${state.posY}px`;
        wrapEl.style.right = 'auto';
        wrapEl.style.bottom = 'auto';
      }
    }

    const style = el('style', { text: `
      :host { all: initial; }

      .bp-wrap {
        position: fixed;
        right: 18px;
        bottom: 18px;
        z-index: 2147483647;
        font-family: ui-sans-serif, system-ui, -apple-system, Segoe UI, Roboto, Arial, sans-serif;
        color: #0b1220;
      }

      .bp-peek {
        width: auto;
        padding: 10px 12px;
        border-radius: 999px;
        background: linear-gradient(135deg, rgba(23,105,255,0.85), rgba(255,59,106,0.55));
        border: 1px solid rgba(255,255,255,0.24);
        color: rgba(255,255,255,0.95);
        font-weight: 850;
        cursor: pointer;
        box-shadow: 0 14px 40px rgba(10, 24, 56, 0.30);
      }

      .bp-panel {
        width: 320px;
        border-radius: 18px;
        overflow: hidden;
        background: linear-gradient(135deg, rgba(255,255,255,0.78), rgba(255,255,255,0.50));
        border: 1px solid rgba(255,255,255,0.55);
        box-shadow:
          0 18px 55px rgba(10, 24, 56, 0.32),
          0 1px 0 rgba(255,255,255,0.55) inset;
        backdrop-filter: blur(18px) saturate(1.3);
        -webkit-backdrop-filter: blur(18px) saturate(1.3);
      }

      .bp-header {
        padding: 12px 14px;
        display: flex;
        align-items: center;
        justify-content: space-between;
        background: linear-gradient(135deg, rgba(23,105,255,0.75), rgba(255,59,106,0.35));
        color: rgba(255,255,255,0.95);
        cursor: grab;
        user-select: none;
      }

      .bp-brand {
        display: flex;
        align-items: center;
        gap: 10px;
        font-weight: 750;
        letter-spacing: 0.2px;
      }

      .bp-dot {
        width: 10px;
        height: 10px;
        border-radius: 999px;
        background: ${state.deviceToken ? 'rgba(39, 214, 140, 1)' : 'rgba(255, 196, 0, 1)'};
        box-shadow: 0 0 0 4px rgba(255,255,255,0.22);
      }

      .bp-mini {
        border: none;
        background: rgba(255,255,255,0.16);
        color: rgba(255,255,255,0.92);
        padding: 6px 10px;
        border-radius: 999px;
        cursor: pointer;
        font-weight: 650;
      }

      .bp-body { padding: 12px 14px 14px; }

      .bp-row { display: flex; gap: 8px; }

      .bp-label {
        font-size: 12px;
        font-weight: 700;
        color: rgba(10, 20, 40, 0.70);
        margin: 10px 0 6px;
        letter-spacing: 0.25px;
      }

      .bp-input {
        width: 100%;
        padding: 10px 12px;
        border-radius: 12px;
        border: 1px solid rgba(12, 20, 40, 0.12);
        background: rgba(255,255,255,0.78);
        outline: none;
        font-size: 13px;
      }

      .bp-input:focus {
        border-color: rgba(23, 105, 255, 0.55);
        box-shadow: 0 0 0 4px rgba(23,105,255,0.16);
      }

      .bp-btn {
        border: none;
        border-radius: 12px;
        padding: 10px 12px;
        cursor: pointer;
        font-weight: 750;
        font-size: 13px;
        color: rgba(255,255,255,0.96);
        background: linear-gradient(135deg, rgba(23,105,255,0.92), rgba(255,59,106,0.62));
        box-shadow: 0 10px 22px rgba(23,105,255,0.20);
      }

      .bp-btn:disabled {
        opacity: 0.55;
        cursor: not-allowed;
      }

      .bp-btn-secondary {
        background: rgba(10, 20, 40, 0.10);
        color: rgba(10, 20, 40, 0.78);
        box-shadow: none;
      }

      .bp-meta {
        font-size: 12px;
        color: rgba(10, 20, 40, 0.64);
        line-height: 1.35;
      }

      .bp-status {
        margin-top: 10px;
        font-size: 12px;
        padding: 10px 10px;
        border-radius: 12px;
        background: rgba(255,255,255,0.60);
        border: 1px solid rgba(12, 20, 40, 0.10);
        color: rgba(10, 20, 40, 0.78);
        min-height: 40px;
        white-space: pre-wrap;
      }

      .bp-actions {
        margin-top: 10px;
        display: flex;
        gap: 8px;
      }

      .bp-link {
        color: rgba(23,105,255,0.96);
        text-decoration: none;
        font-weight: 750;
      }

      .bp-link:hover { text-decoration: underline; }

      .bp-small {
        font-size: 11px;
        color: rgba(10, 20, 40, 0.55);
        margin-top: 8px;
      }

      .bp-hidden { display: none; }
    ` }, []);

    const wrap = el('div', { class: 'bp-wrap', id: 'bpWrap' });
    applyPosition(wrap);

    if (state.panelHidden) {
      const peek = el('button', { class: 'bp-peek', id: 'bpPeekBtn', text: 'Blueprint Sync' });
      wrap.appendChild(peek);
      shadow.appendChild(style);
      shadow.appendChild(wrap);
      return;
    }

    const panel = el('div', { class: 'bp-panel' });

    const header = el('div', { class: 'bp-header', id: 'bpHeader' }, [
      el('div', { class: 'bp-brand' }, [
        el('span', { class: 'bp-dot' }),
        el('span', { text: 'Blueprint Sync' }),
      ]),
      el('button', { class: 'bp-mini', id: 'bpHideBtn', text: 'Hide' }),
      el('button', { class: 'bp-mini', id: 'bpMinBtn', text: state.minimized ? 'Expand' : 'Minimize' }),
    ]);

    const body = el('div', { class: 'bp-body' });

    const pairedLine = state.pairedUser?.email
      ? `Paired as ${state.pairedUser.email}`
      : state.deviceToken
        ? 'Paired'
        : 'Not paired yet';

    const meta = el('div', { class: 'bp-meta' }, [
      el('div', { text: pairedLine }),
      state.lastSyncAt ? el('div', { text: `Last sync: ${formatIso(state.lastSyncAt)}` }) : null,
    ]);

    const linkCodeBox = el('div', { id: 'bpLinkCodeBox', class: state.deviceToken ? 'bp-hidden' : '' }, [
      el('div', { class: 'bp-label', text: 'Link Code (from Blueprint)' }),
      el('input', { class: 'bp-input', id: 'bpLinkCodeInput', placeholder: 'e.g. 7J4QH-2K9PM' }),
      el('div', { class: 'bp-actions' }, [
        el('button', { class: 'bp-btn', id: 'bpPairBtn', text: 'Pair' }),
        el('button', { class: 'bp-btn bp-btn-secondary', id: 'bpOpenBlueprintBtn', text: 'Open Blueprint' }),
      ]),
      el('div', { class: 'bp-small', text: 'You only do this once. After pairing, you can sync anytime.' }),
    ]);

    const syncBox = el('div', { id: 'bpSyncBox', class: state.deviceToken ? '' : 'bp-hidden' }, [
      el('div', { class: 'bp-label', text: 'Sync' }),
      el('div', { class: 'bp-row' }, [
        el('button', { class: 'bp-btn', id: 'bpSyncBtn', text: state.syncing ? 'Syncing...' : 'Sync now', disabled: !!state.syncing }),
        el('button', { class: 'bp-btn bp-btn-secondary', id: 'bpDisconnectBtn', text: 'Disconnect', disabled: !!state.syncing }),
      ]),
      el('div', { class: 'bp-small' }, [
        'After syncing, go back to ',
        el('a', { class: 'bp-link', href: BLUEPRINT_APP_URL, target: '_blank', rel: 'noreferrer', text: 'Blueprint' }),
        ' to see the dashboard.'
      ]),
    ]);

    const settings = el('div', { class: state.minimized ? 'bp-hidden' : '' }, [
      el('div', { class: 'bp-label', text: 'Blueprint API Base (advanced)' }),
      el('input', { class: 'bp-input', id: 'bpApiBaseInput', value: state.apiBase || '' }),
      el('div', { class: 'bp-small', text: 'Leave as-is unless you changed your backend URL.' }),
    ]);

    const status = el('div', { class: 'bp-status', id: 'bpStatus', text: state.statusText || state.lastSyncSummary || 'Ready.' });

    body.appendChild(meta);
    if (!state.minimized) {
      body.appendChild(linkCodeBox);
      body.appendChild(syncBox);
      body.appendChild(settings);
      body.appendChild(status);
    }

    panel.appendChild(header);
    panel.appendChild(body);
    wrap.appendChild(panel);

    shadow.appendChild(style);
    shadow.appendChild(wrap);
  }

  async function mount() {
    if (document.getElementById('blueprint-canvas-sync-host')) return;

    const host = document.createElement('div');
    host.id = 'blueprint-canvas-sync-host';
    host.style.position = 'fixed';
    host.style.right = '0';
    host.style.bottom = '0';
    host.style.zIndex = '2147483647';
    host.attachShadow({ mode: 'open' });
    document.documentElement.appendChild(host);

    let state = {
      apiBase: null,
      deviceToken: null,
      pairedUser: null,
      lastSyncAt: null,
      lastSyncSummary: null,
      panelHidden: false,
      minimized: false,
      posX: null,
      posY: null,
      syncing: false,
      statusText: '',
    };

    async function refreshConfig() {
      const resp = await sendMessage({ type: 'GET_CONFIG' });
      if (resp?.ok) {
        state = {
          ...state,
          ...resp.config,
        };
      }
      buildPanel(host, state);
      bind();
    }

    function setStatus(text) {
      state.statusText = String(text || '');
      buildPanel(host, state);
      bind();
    }

    async function bind() {
      const shadow = host.shadowRoot;
      const wrap = shadow.getElementById('bpWrap');

      const persistUi = async (patch) => {
        await sendMessage({ type: 'SET_UI_PREFS', ...(patch || {}) });
      };

      const peekBtn = shadow.getElementById('bpPeekBtn');
      if (peekBtn) {
        peekBtn.onclick = async () => {
          state.panelHidden = false;
          await persistUi({ panelHidden: false });
          buildPanel(host, state);
          bind();
        };
      }

      const hideBtn = shadow.getElementById('bpHideBtn');
      if (hideBtn) {
        hideBtn.onclick = async () => {
          state.panelHidden = true;
          await persistUi({ panelHidden: true });
          buildPanel(host, state);
          bind();
        };
      }

      const minBtn = shadow.getElementById('bpMinBtn');
      if (minBtn) {
        minBtn.onclick = async () => {
          state.minimized = !state.minimized;
          await persistUi({ minimized: state.minimized });
          buildPanel(host, state);
          bind();
        };
      }

      // Drag to move (header or the hidden peek pill).
      const header = shadow.getElementById('bpHeader');
      const dragHandle = header || peekBtn;
      if (wrap && dragHandle && !dragHandle.__bpDragBound) {
        dragHandle.__bpDragBound = true;
        dragHandle.addEventListener('pointerdown', (ev) => {
          if (ev.button !== 0) return;
          ev.preventDefault();

          dragHandle.setPointerCapture?.(ev.pointerId);

          const rect0 = wrap.getBoundingClientRect();
          const offsetX = ev.clientX - rect0.left;
          const offsetY = ev.clientY - rect0.top;

          const onMove = (e) => {
            const rect = wrap.getBoundingClientRect();
            const vw = window.innerWidth || 0;
            const vh = window.innerHeight || 0;
            const w = rect.width || 320;
            const h = rect.height || 60;

            let x = e.clientX - offsetX;
            let y = e.clientY - offsetY;

            x = Math.max(8, Math.min(x, Math.max(8, vw - w - 8)));
            y = Math.max(8, Math.min(y, Math.max(8, vh - h - 8)));

            state.posX = Math.round(x);
            state.posY = Math.round(y);

            wrap.style.left = `${state.posX}px`;
            wrap.style.top = `${state.posY}px`;
            wrap.style.right = 'auto';
            wrap.style.bottom = 'auto';
          };

          const onUp = async () => {
            window.removeEventListener('pointermove', onMove);
            window.removeEventListener('pointerup', onUp);
            await persistUi({ posX: state.posX, posY: state.posY });
          };

          window.addEventListener('pointermove', onMove);
          window.addEventListener('pointerup', onUp, { once: true });
        });
      }

      const openBlueprintBtn = shadow.getElementById('bpOpenBlueprintBtn');
      if (openBlueprintBtn) {
        openBlueprintBtn.onclick = () => {
          window.open(BLUEPRINT_APP_URL, '_blank', 'noreferrer');
        };
      }

      const apiBaseInput = shadow.getElementById('bpApiBaseInput');
      if (apiBaseInput) {
        apiBaseInput.onchange = async () => {
          const apiBase = apiBaseInput.value.trim();
          const resp = await sendMessage({ type: 'SET_API_BASE', apiBase });
          if (!resp?.ok) {
            setStatus(`Error saving API base: ${resp?.error || 'unknown'}`);
            return;
          }
          state.apiBase = resp.apiBase;
          setStatus('Saved API base.');
        };
      }

      const pairBtn = shadow.getElementById('bpPairBtn');
      if (pairBtn) {
        pairBtn.onclick = async () => {
          const linkCode = shadow.getElementById('bpLinkCodeInput')?.value || '';
          const apiBase = shadow.getElementById('bpApiBaseInput')?.value || state.apiBase;

          setStatus('Pairing...');

          const resp = await sendMessage({ type: 'EXCHANGE_LINK_CODE', apiBase, linkCode });
          if (!resp?.ok) {
            setStatus(`Pair failed: ${resp?.error || 'unknown error'}`);
            return;
          }

          await refreshConfig();
          setStatus('Paired. You can sync now.');
        };
      }

      const disconnectBtn = shadow.getElementById('bpDisconnectBtn');
      if (disconnectBtn) {
        disconnectBtn.onclick = async () => {
          const resp = await sendMessage({ type: 'CLEAR_PAIRING' });
          if (!resp?.ok) {
            setStatus(`Disconnect failed: ${resp?.error || 'unknown error'}`);
            return;
          }
          await refreshConfig();
          setStatus('Disconnected.');
        };
      }

      const syncBtn = shadow.getElementById('bpSyncBtn');
      if (syncBtn) {
        syncBtn.onclick = async () => {
          if (state.syncing) return;
          state.syncing = true;
          buildPanel(host, state);
          bind();

          try {
            const apiBase = shadow.getElementById('bpApiBaseInput')?.value || state.apiBase;
            if (!state.deviceToken) throw new Error('Not paired.');

            const payload = await getCanvasData((m) => setStatus(m));
            setStatus(`Uploading to Blueprint...`);

            const resp = await sendMessage({
              type: 'IMPORT_DATA',
              apiBase,
              deviceToken: state.deviceToken,
              payload,
            });

            if (!resp?.ok) throw new Error(resp?.error || 'Import failed');

            await refreshConfig();
            setStatus(`✅ ${resp.summary || 'Synced.'}`);
          } catch (e) {
            setStatus(`❌ ${String(e?.message || e)}`);
          } finally {
            state.syncing = false;
            buildPanel(host, state);
            bind();
          }
        };
      }
    }

    await refreshConfig();

    // Helpful initial hint if the user is not logged in.
    try {
      // This will fail if the user is not logged in.
      await fetchJson(`${window.location.origin}/api/v1/users/self`);
    } catch {
      setStatus('You may need to sign in to Canvas before syncing.');
    }
  }

  // Canvas pages can be SPA-like; mount after a short delay.
  setTimeout(() => mount().catch(() => {}), 700);
}
